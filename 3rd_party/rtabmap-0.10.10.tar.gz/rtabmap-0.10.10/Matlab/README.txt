This directory contains some basic concepts on Bayes filtering.
Main scripts :
 RecursivesBayes.m
 RecursivesBayesAvpd.m