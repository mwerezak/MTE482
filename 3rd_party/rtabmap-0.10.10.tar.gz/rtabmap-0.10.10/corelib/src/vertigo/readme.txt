
Info: http://openslam.org/vertigo.html
Source: https://github.com/christiankerl/vertigo/tree/master/trunk
Commit: fbd438488a56cdba805fa2f75aa3e394e3eda7ff
License: GPL v3

Tested with g2o (ROS Indigo/2014.02.18)
Tested with GTSAM commit c73b835