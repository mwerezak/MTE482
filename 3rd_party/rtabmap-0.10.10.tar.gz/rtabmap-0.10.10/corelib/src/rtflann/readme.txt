
flann is included in rtabmap for convenience, to have this commit needed for incremental flann index:
https://github.com/mariusmuja/flann/commit/23051820b2314f07cf40ba633a4067782a982ff3

Info: http://www.cs.ubc.ca/research/flann/
Source: https://github.com/mariusmuja/flann
Commit: 9a01507d2231b29eb688246a6e442054defa7460
License: BSD 