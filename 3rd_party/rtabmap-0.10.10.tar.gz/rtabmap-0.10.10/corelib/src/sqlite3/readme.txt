
Info: https://www.sqlite.org/
License: Public domain (https://www.sqlite.org/copyright.html)