
Info: https://www.openslam.org/toro.html
License: Creative Commons (Attribution-NonCommercial-ShareAlike)